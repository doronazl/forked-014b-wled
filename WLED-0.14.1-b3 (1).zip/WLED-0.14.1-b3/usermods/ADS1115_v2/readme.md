# ADS1115 16-Bit ADC with four inputs

This usermod will read from an ADS1115 ADC. The voltages are displayed in the Info section of the web UI.

Configuration is performed via the Usermod menu. There are no parameters to set in code!

## Installation 

Add the build flag `-D USERMOD_ADS1115` to your platformio environment.
Uncomment libraries with comment `#For ADS1115 sensor uncomment following`
